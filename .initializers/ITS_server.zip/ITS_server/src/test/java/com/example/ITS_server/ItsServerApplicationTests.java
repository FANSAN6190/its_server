package com.example.ITS_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
